public class Aluno{
  public String nome;
  public byte idade;
  private boolean estado_civil; 
  protected int altura;

  public void estudar(){
  }
  private void caminhar(){
  }
  public String ler(){
   return "Ola vamos ler?? ";
  }
  public void implementar(){
  }
  public int fazer_exercicios(int quantidade){
   return 3;
  }
  protected boolean comer(String comida){
  return true;    
}
  
}
