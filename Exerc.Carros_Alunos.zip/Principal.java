public class Principal{
	public static void main(String arg[]){
		System.out.println("inicio do prog");
                Carro car1;
                car1= new Carro();
                car1.ligar();
                car1.ano=10;
		System.out.println("fim do prog");
	}
}