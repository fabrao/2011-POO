public class Carro{
    private String cor; // "-"
    public int ano;     // "+"
    protected int motor;// "#"
    
    public void ligar(){ // "+" "equivalente a fun��o em C"
        System.out.println("ligou");
    }
    protected boolean ligar_farois(int id){
        System.out.println("ligou: "+ id);
        return true;
    }
    
    private void desligar(){
        System.out.println("Desligou");
    }
}