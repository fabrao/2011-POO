public class Principal{
	public static void main(String arg[]){
		
		System.out.println("inicio...");
		Carro car1;
		car1= new Carro();
		car1.cor= "Branco";
		car1.setCor("Azul");
		System.out.println("Valor da cor: "+car1.cor);
		System.out.println("fim...");
	}
}