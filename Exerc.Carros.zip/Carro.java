public class Carro{
	public String cor;
	public void setCor(String cor_temp){
		cor = cor_temp;
	}
}